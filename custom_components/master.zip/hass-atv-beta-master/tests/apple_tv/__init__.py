"""Tests for Apple TV."""
